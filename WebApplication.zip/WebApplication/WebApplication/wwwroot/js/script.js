$(document).ready(function () {

    $(".add_basket").click(function () {
        var Id = $(this).attr("data-id");
        console.log(Id);
        var self = $(this);
        $.ajax({
            url: "Product/AddBasket?id=" + Id,
            type: "GET",
            success: function (res) {
                self.css("background-color", "red");
                self.attr("disabled", "disabled");
            }
        });
    })

    $("#search").keyup(function () {
        var src = $(this).val();
        $("#search_list").empty();
        if (src.length > 0) {
            $.ajax({
                url: "Home/SearchStudent?str=" + src,
                type: "GET",
                success: function (res) {
                    $("#search_list").append(res)
                }
            });
        }
        
    })


    var skipindex = 4;
    $("#load_more_work").click(function () {
        var workCount = $("#work_count").val();
        $.ajax({
            url: "Home/LoadMoreWork?skip=" + skipindex,
            type: "GET",
            success: function (response) {
                $(".load_work").append(response);
                skipindex += 4;
                if (skipindex >= workCount) {
                    $("#load_more_work").remove();
                }
                //old variant
                //for (var i = 0; i < response.length; i++) {
                //    var div = $("<div>").addClass("col-3");
                //    var img = $("<img>").attr("src", "/img/" + response[i].image);
                //    img.appendTo(div);
                //    $(".load_work").append(div);
                //}
            }
        })
    })

	$(".navbar-nav .nav-link ").attr("style", "color: white !important");
    var check = true;
    var black_img = $("#black_img").text();
    var white_img = $("#white_img").text();
    $(window).scroll(function () {
        
        //console.log("black_img:" + black_img + " white_img:" + white_img)
        if (scrollY > 140) {
            $("header").css("background-color", "white");
            $("header").css("boxShadow", "10px 20px 30px lightgray");
            $(".navbar-brand img").attr("src", "img/" + black_img);
            $(".navbar-nav .nav-link ").attr("style", "color: black !important");
        } else {
            $("header").css("background-color", "");
            $(".navbar-brand img").attr("src", "img/" + white_img);
            $(".navbar-nav .nav-link ").attr("style", "color: white !important");
            $("header").css("boxShadow", "0px 0px 0px lightgray");
        }
	// zzzzzzzzz// statistics counter///////////////////////////////////start zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz


		$('#results').each(function () {
			var $this = $(this), countTo = $this.attr('data-count');
			var bottom_of_object = $(this).position().top + $(this).outerHeight();
			var bottom_of_window = $(window).scrollTop() + $(window).height();
		
			if (bottom_of_window > bottom_of_object && check) {
				
				var numbers = $("#results h1");
			
				for (var i = 0; i < numbers.length; i++) {
					counting(numbers[i]);
				}
			}
			if (bottom_of_window > bottom_of_object){
			
				check=false;
			}
			else{
				check=true;
			}
		});
	})
	var counting = function (n) {
 var num_value = $(n).data("count");
		$({ Counter: 0 }).animate({
			Counter: num_value
		  }, {
			duration: 3000,
			easing: 'swing',
			step: function() {
			  $(n).text(Math.ceil(this.Counter));
			}
		  });
		
		
	}
//zzzzzz//statistics counter/////////////////////////////endd//zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz




	//main slider start
	// individual slide animations
	var slides = function slides(i) {
		// var _from = '#slide-1';
		var _to = '#slide-' + i;
		var bg = '#slide-' + i + ' .bg';
		var title = '#slide-' + i + ' h1';
		var text = '#slide-' + i + ' p';

		TweenLite.from(bg, 1, { scale: 1.25 });
		TweenLite.from(title, 1, { y: '105px', autoAlpha: 0 });
		TweenLite.from(text, 1, { delay: .5, y: '105px', autoAlpha: 0 });
	};

	// setup for the flickity slider
	var slideFlickity = function slideFlickity() {
		// flickity init	
		var slideList = $('.main-carousel').flickity({
			cellAlign: 'center',
			wrapAround: true,
			pageDots: true
		});

		slideClick(slideList);
	};

	var slideClick = function slideClick(slideList) {
		slideList.data('flickity').on('select', function () {
			var index = this.selectedIndex + 1;
			slides(index);
		});
	};

	// load flickity first
	slideFlickity();

	// intro animation second
	TweenLite.from('#slide-1 .bg', 1, { autoAlpha: 0 });
	TweenLite.from('#slide-1 h1', 1.5, { autoAlpha: 0, y: '-105px' });
	TweenLite.from('#slide-1 p', 1.5, { autoAlpha: 0, y: '105px' });
	TweenLite.from('.previous', .5, { x: '-50px' });
	TweenLite.from('.next', .5, { x: '50px' });
	TweenLite.from('.flickity-page-dots', .5, { y: '105%' });





	

	// brand slider start

	$('.customer-logos').slick({
		slidesToShow: 6,
		slidesToScroll: 1,
		autoplay: true,
		autoplaySpeed: 1000,
		arrows: false,
		dots: false,
		pauseOnHover: false,
		responsive: [{
			breakpoint: 768,
			settings: {
				slidesToShow: 4
			}
		}, {
			breakpoint: 520,
			settings: {
				slidesToShow: 3
			}
		}]
	});
	//brand slider end





})



