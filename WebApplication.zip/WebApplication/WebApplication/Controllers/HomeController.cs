﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebApplication.DAL;

namespace WebApplication.Controllers
{
    public class HomeController : Controller
    {
        private AppDbContext _context;
        public HomeController(AppDbContext context)
        {
            _context = context;
        }
        public IActionResult Index()
        {
            HttpContext.Session.SetString("color", "red");
            ViewBag.FavLang = Request.Cookies["fav_lang"];
            ViewBag.WorkCount = _context.OurWorks.Count();
            return View();
        }

        public IActionResult Testsession()
        {
            string sesionColor = HttpContext.Session.GetString("color");
            return Content(sesionColor);
        }

        public IActionResult LoadMoreWork(int skip)
        {
            #region Return Json
            //return Json(_context.OurWorks.Select(w=>new
            //{
            //    w.Image
            //}));
            #endregion

            var model = _context.OurWorks.Skip(skip).Take(4);
            return PartialView("_OurWorkPartial", model);

        }

        public IActionResult ChangeLang()
        {
            HttpContext.Response.Cookies.Append("fav_lang", "en", new CookieOptions { MaxAge = TimeSpan.FromMinutes(10) });
            return Ok(new
            {
                status=200,
                data="",
                error=""
            });
        }

        public IActionResult SearchStudent(string str)
        {
            var model = _context.Students.Where(s => s.Name.Contains(str) || s.Surname.Contains(str)).Take(4);
            return PartialView("_SearchPartial", model);
        }
    }
}