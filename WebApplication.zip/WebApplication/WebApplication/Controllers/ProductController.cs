﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using WebApplication.DAL;
using WebApplication.Models;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using WebApplication.ViewModel;

namespace WebApplication.Controllers
{
    public class ProductController : Controller
    {
        private AppDbContext _context;
        public ProductController(AppDbContext context)
        {
            _context = context;
        }
        public IActionResult Index()
        {
            string currentBasket = HttpContext.Session.GetString("products");
            ProductViewModel productView = null;
            if (currentBasket != null)
            {
                productView = new ProductViewModel()
                {
                    ProductsDb = _context.Products,
                    ProductsSession= JsonConvert.DeserializeObject<List<Product>>(currentBasket)
                 };
            }
            else
            {
                productView = new ProductViewModel()
                {
                    ProductsDb = _context.Products,
                    ProductsSession = null
                };
            }
            return View(productView);
        }

        public async Task<IActionResult> AddBasket(int? id)
        {
            Product product =await _context.Products.FindAsync(id);
            string currentBasket = HttpContext.Session.GetString("products");
            List<Product> products = null;
            if (currentBasket != null)
            {
                products = JsonConvert.DeserializeObject<List<Product>>(currentBasket);
            }
            else
            {
                products = new List<Product>();
            }
            
            products.Add(product);

            string jsonResult=JsonConvert.SerializeObject(products);

            HttpContext.Session.SetString("products", jsonResult);
            return Json(true);
        }

        public IActionResult Basket()
        {
            string products = HttpContext.Session.GetString("products");
            List<Product>  viewProducts=JsonConvert.DeserializeObject<List<Product>>(products);
            return View(viewProducts);
        }
    }
}