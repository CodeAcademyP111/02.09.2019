﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication.DAL;

namespace WebApplication.ViewComponents
{
    public class WorksViewComponent:ViewComponent
    {
        private AppDbContext _context;
        public WorksViewComponent(AppDbContext context)
        {
            _context = context;
        }

        public async Task<IViewComponentResult> InvokeAsync(int take)
        {
            var works=_context.OurWorks.Take(take);
            return View(await Task.FromResult(works));
        }
    }
}
