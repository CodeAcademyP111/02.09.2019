﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication.Models;

namespace WebApplication.ViewModel
{
    public class ProductViewModel
    {
        public IEnumerable<Product> ProductsDb { get; set; }

        public List<Product> ProductsSession { get; set; }
    }
}
